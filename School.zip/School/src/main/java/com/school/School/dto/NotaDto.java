package com.school.School.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class NotaDto {

    private int id;
    private int nota;
    private String materie;
    private int elevId;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate data;

}
