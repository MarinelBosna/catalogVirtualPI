package com.school.School.service;

import com.school.School.entities.Elev;
import com.school.School.entities.Nota;
import com.school.School.repo.NotaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NotaService {

    @Autowired
    private NotaRepository notaRepository;

    public void salveazaNota(Nota nota) {
        notaRepository.save(nota);
    }

    public void deleteNota(int id) {
        Nota nota = getNotaById(id);
        notaRepository.delete(nota);
    }

    public Nota getNotaById(int id) {
        return notaRepository.findById(id);
    }
}
