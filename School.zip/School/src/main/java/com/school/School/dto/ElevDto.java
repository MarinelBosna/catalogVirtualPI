package com.school.School.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ElevDto {
    private int id;
    private String nume;
    private String prenume;

    private List<NotaDto> note = new ArrayList<>();
    private List<AbsentaDto> absente = new ArrayList<>();
}
