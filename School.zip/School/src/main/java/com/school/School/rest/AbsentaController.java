package com.school.School.rest;

import com.school.School.dto.AbsentaDto;
import com.school.School.dto.NotaDto;
import com.school.School.entities.Absenta;
import com.school.School.entities.Elev;
import com.school.School.entities.Nota;
import com.school.School.service.AbsentaService;
import com.school.School.service.ElevService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;

@Controller
@RequestMapping("/absente")
public class AbsentaController {

    @Autowired
    private AbsentaService absentaService;

    @Autowired
    private ElevService elevService;

    @GetMapping("/creeaza/{elevId}")
    public String addAbsenta(Model model, @PathVariable("elevId") int elevId){

        Absenta absenta = new Absenta();
//        no.setElev(elevService.getElevById(elevId));
        model.addAttribute("absenta", absenta);
        return "addAbsenta";
    }

    @PostMapping("/salveazaAbsenta/{elevId}")
    public String salveazaAbsenta(AbsentaDto absentaDto, @PathVariable("elevId") int elevId) {
        Absenta absenta = new Absenta();
        if(absentaDto.getData() == null)
            absenta.setData(LocalDate.now());
        else
            absenta.setData(absentaDto.getData());
        absenta.setMaterie(absentaDto.getMaterie());
        Elev elevById = elevService.getElevById(elevId);
        absenta.setElev(elevById);
        absentaService.salveazaAbsenta(absenta);

        return "redirect:/elevi/vizualizare/" + elevId;
    }

    @GetMapping("/sterge/{id}")
    public String stergeNota(HttpServletRequest req, @PathVariable("id") int id) {
        absentaService.deleteAbsenta(id);
        String refered = req.getHeader("Referer");
        return "redirect:" + refered;
    }


    @GetMapping("/editAbsenta/{id}")
    public String editNota(@PathVariable("id") int id, Model model) {
        ModelMapper modelMapper = new ModelMapper();
        Absenta absenta = absentaService.getAbsentaById(id);
        AbsentaDto absentaDto = modelMapper.map(absenta, AbsentaDto.class);
        model.addAttribute("absenta", absentaDto);
        return "editAbsenta";
    }

    @PostMapping("/modifica/{id}")
    public String updateAbsenta(HttpServletRequest req, AbsentaDto absentaDto) {
        ModelMapper modelMapper = new ModelMapper();

        Absenta absenta = absentaService.getAbsentaById(absentaDto.getId());
        Elev elevById = absenta.getElev();
        absenta.setMaterie(absentaDto.getMaterie());
        absenta.setData(absentaDto.getData());
        absentaService.salveazaAbsenta(absenta);
        String refered = req.getHeader("Referer");
        return "redirect:/elevi/vizualizare/" + elevById.getId();
    }
}
