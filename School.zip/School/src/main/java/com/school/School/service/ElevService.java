package com.school.School.service;

import com.school.School.entities.Elev;
import com.school.School.repo.ElevRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ElevService {
    @Autowired
    ElevRepository elevRepository;

    public Elev salveazaElev(Elev elev) {
      return elevRepository.save(elev);
    }

    public Elev getElevById(int id) {
        return elevRepository.findById(id);
    }

    public void deleteElev(int id){
        Elev elev = getElevById(id);
        elevRepository.delete(elev);
    }

    public List<Elev> getElevi() {

        return elevRepository.findAll();
    }
}
