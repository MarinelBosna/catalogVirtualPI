package com.school.School.entities;

import com.sun.istack.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "elevi")
@AllArgsConstructor
@NoArgsConstructor
public class Elev {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    @Column(nullable = false)
    private String nume;
    @Column(nullable = false)
    private String prenume;

    @OneToMany(mappedBy = "elev", cascade = CascadeType.ALL)
    private List<Nota> note = new ArrayList<>();

    @OneToMany(mappedBy = "elev", cascade = CascadeType.ALL)
    private List<Absenta> absente = new ArrayList<Absenta>();
}
