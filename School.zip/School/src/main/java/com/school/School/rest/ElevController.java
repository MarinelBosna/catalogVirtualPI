package com.school.School.rest;

import com.school.School.dto.AbsentaDto;
import com.school.School.dto.ElevDto;
import com.school.School.dto.NotaDto;
import com.school.School.entities.Elev;
import com.school.School.service.ElevService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/elevi")
public class ElevController {

    @Autowired
    private ElevService elevService;

    @GetMapping
    public String getElevi(Model model) {
        ModelMapper modelMapper = new ModelMapper();

        List<Elev> elevi = elevService.getElevi();
        List<ElevDto> eleviDto = elevi.stream()
                .map(elev -> modelMapper.map(elev, ElevDto.class))
                .collect(Collectors.toList());

        model.addAttribute("name", "ere");
        model.addAttribute("elevi", eleviDto);
        return "elevi";
    }

    @GetMapping("/creeaza")
    public String creeazaElev(Model model) {
        model.addAttribute("elev", new Elev());
        return "addElev";
    }

    @PostMapping("/salveazaElev")
    public String salveazaElev(ElevDto elevDto) {
        ModelMapper modelMapper = new ModelMapper();
        Elev elev = modelMapper.map(elevDto, Elev.class);
        elevService.salveazaElev(elev);
        return "redirect:/elevi";
    }


    @GetMapping("/vizualizare/{id}")
    public String vizualizareElev(@PathVariable("id") int id, Model model) {
        ModelMapper modelMapper = new ModelMapper();
        Elev elev = elevService.getElevById(id);
        ElevDto elevDto = modelMapper.map(elev, ElevDto.class);
        List<NotaDto> noteDtos = elev.getNote().stream().map(nota -> modelMapper.map(nota, NotaDto.class)).collect(Collectors.toList());
        List<AbsentaDto> absentaDtos = elev.getAbsente().stream().map(absenta -> modelMapper.map(absenta, AbsentaDto.class)).collect(Collectors.toList());
        model.addAttribute("elev", elevDto);
        model.addAttribute("noteDtos", noteDtos);
        model.addAttribute("absenteDtos", absentaDtos);
        return "elev";
    }

    @GetMapping("/sterge/{id}")
    public String stergeElev(@PathVariable("id") int id) {
        elevService.deleteElev(id);
        return "redirect:/elevi";
    }

    @GetMapping("/editElev/{id}")
    public String editElev(@PathVariable("id") int id, Model model) {
        ModelMapper modelMapper = new ModelMapper();
        Elev elev = elevService.getElevById(id);
        ElevDto elevDto = modelMapper.map(elev, ElevDto.class);
        model.addAttribute("elev", elevDto);
        return "editElev";
    }

    @PostMapping("/modifica/{id}")
    public String updateElev(ElevDto elevDto) {
        ModelMapper modelMapper = new ModelMapper();
        elevService.salveazaElev(modelMapper.map(elevDto, Elev.class));
        return "redirect:/elevi";
    }
}
