package com.school.School.rest;

import com.school.School.dto.ElevDto;
import com.school.School.dto.NotaDto;
import com.school.School.entities.Elev;
import com.school.School.entities.Nota;
import com.school.School.service.ElevService;
import com.school.School.service.NotaService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;

@Controller
@RequestMapping("/note")
public class NotaController {

    @Autowired
    private NotaService notaService;

    @Autowired
    private ElevService elevService;

    @GetMapping("/creeaza/{elevId}")
    public String addNota(Model model, @PathVariable("elevId") int elevId){

        Nota no = new Nota();
//        no.setElev(elevService.getElevById(elevId));
        model.addAttribute("nota", no);
        return "addNota";
    }

    @PostMapping("/salveazaNota/{elevId}")
    public String salveazaNota( NotaDto notaDto, @PathVariable("elevId") int elevId) {
        Nota nota = new Nota();
        nota.setNota(notaDto.getNota());
        nota.setMaterie(notaDto.getMaterie());
        nota.setElev(elevService.getElevById(elevId));
        if(notaDto.getData() == null)
            nota.setData(LocalDate.now());
        else
            nota.setData(notaDto.getData());
        notaService.salveazaNota(nota);

        return "redirect:/elevi/vizualizare/" + elevId;
    }

    @GetMapping("/sterge/{id}")
    public String stergeNota(HttpServletRequest req, @PathVariable("id") int id) {
        notaService.deleteNota(id);
        String refered = req.getHeader("Referer");
        return "redirect:" + refered;
    }


    @GetMapping("/editNota/{id}")
    public String editNota(@PathVariable("id") int id, Model model) {
        ModelMapper modelMapper = new ModelMapper();
        Nota nota = notaService.getNotaById(id);
        NotaDto notaDto = modelMapper.map(nota, NotaDto.class);
        model.addAttribute("nota", notaDto);
        return "editNota";
    }

    @PostMapping("/modifica/{id}")
    public String updateNota(HttpServletRequest req, NotaDto notaDto) {
        ModelMapper modelMapper = new ModelMapper();
        Elev elevById = notaService.getNotaById(notaDto.getId()).getElev();
        Nota nota = notaService.getNotaById(notaDto.getId());
        nota.setMaterie(notaDto.getMaterie());
        nota.setNota(notaDto.getNota());
        nota.setData(notaDto.getData());
        notaService.salveazaNota(nota);
        String refered = req.getHeader("Referer");
        return "redirect:/elevi/vizualizare/" + elevById.getId();
    }
}
