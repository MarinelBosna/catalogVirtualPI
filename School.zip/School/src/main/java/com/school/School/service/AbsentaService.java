package com.school.School.service;

import com.school.School.entities.Absenta;
import com.school.School.repo.AbsentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AbsentaService {
    @Autowired
    private AbsentaRepository absentaRepository;

    public void salveazaAbsenta(Absenta absenta) {
        absentaRepository.save(absenta);
    }

    public void deleteAbsenta(int id) {
        Absenta absenta = getAbsentaById(id);
        absentaRepository.delete(absenta);
    }

    public Absenta getAbsentaById(int id) {
        return absentaRepository.findById(id);
    }
}
